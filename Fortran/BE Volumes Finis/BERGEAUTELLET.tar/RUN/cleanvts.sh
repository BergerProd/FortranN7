
for i in *.vts
do rm $i
done
